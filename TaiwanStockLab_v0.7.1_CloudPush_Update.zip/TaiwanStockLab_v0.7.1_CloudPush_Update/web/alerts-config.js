/* Public configuration only. Never place Fugle API Key, CONTROL_TOKEN or Firebase private keys here. */
globalThis.STOCKLAB_ALERTS_CONFIG = {
  workerUrl: '', // Set to https://taiwan-stock-lab-alerts.<your-subdomain>.workers.dev
  firebase: {apiKey:'',authDomain:'',projectId:'',appId:'',messagingSenderId:''},
  vapidKey: '' // Public Firebase Web Push VAPID key; only required for browser push.
};
