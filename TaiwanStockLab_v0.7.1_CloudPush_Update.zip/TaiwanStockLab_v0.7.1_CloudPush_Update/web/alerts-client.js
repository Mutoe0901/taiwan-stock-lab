/* Taiwan Stock Lab 0.7.1: authenticated cloud H1 and FCM subscriber registration. */
(()=>{
'use strict';
const cfg=globalThis.STOCKLAB_ALERTS_CONFIG||{}, $=id=>document.getElementById(id);
let access=''; // pairing token intentionally stays in memory, not localStorage/Preferences.
let loaded=null;
const write=(text,bad=false)=>{const el=$('alerts-status');if(el){el.textContent=text;el.style.color=bad?'#bf404a':'';}};
function base(){const url=(cfg.workerUrl||'').replace(/\/$/,'');if(!/^https:\/\/[^/]+$/.test(url))throw Error('請先在 alerts-config.js 設定 HTTPS Worker URL');return url;}
async function api(path,{method='GET',data}={}){
 if(!access)throw Error('請先輸入雲端配對密碼並連線');
 const res=await fetch(base()+path,{method,headers:{Authorization:'Bearer '+access,...(data?{'Content-Type':'application/json'}:{})},body:data?JSON.stringify(data):undefined,cache:'no-store'});
 const payload=await res.json().catch(()=>({error:'非 JSON 回應'}));if(!res.ok)throw Error(payload.error||'服務連線失敗 HTTP '+res.status);return payload;
}
function selected(){return ['BUY IN','SELL IN','PROFIT OUT','FAIL OUT'].reduce((v,k)=>({...v,[k]:!!$('alerts-'+k.replace(/ /g,'-'))?.checked}),{});}
function display(s){$('alerts-symbols').value=s.symbols.join(',');$('alerts-ratio').value=s.volumeRatio;for(const [k,v] of Object.entries(s.flags))if($('alerts-'+k.replace(/ /g,'-')))$('alerts-'+k.replace(/ /g,'-')).checked=v;}
async function connect(){access=$('alerts-pair').value.trim();$('alerts-pair').value='';const s=await api('/api/settings');loaded=s;display(s);write('已連接雲端監控；Fugle 金鑰不會傳到裝置。');}
async function save(){const symbols=$('alerts-symbols').value.split(/[,，\s]+/).filter(Boolean);const v=await api('/api/settings',{method:'POST',data:{symbols,flags:selected(),volumeRatio:Number($('alerts-ratio').value)}});loaded=v;display(v);write('已保存雲端自選股及 A/B 四種通知設定');}
async function registerAndroid(){const cap=globalThis.StocklabCapacitor;
 if(!cap?.Capacitor?.isNativePlatform?.())return false;
 const Push=cap.registerPlugin?.('PushNotifications');if(!Push)throw Error('Android 未載入 Capacitor PushNotifications 插件，請安裝新版 APK');
 await Push.addListener('registration', async ({value})=>{try{await api('/api/register',{method:'POST',data:{token:value,platform:'android'}});write('Android FCM 推播已註冊；App 關閉後仍可接收雲端通知');}catch(err){write(err.message,true);}});
 await Push.addListener('registrationError', e=>write('FCM 註冊失敗：'+JSON.stringify(e),true));
 await Push.createChannel({id:'stocklab_signals',name:'台股交易訊號',description:'H1 A/B 進場及離場',importance:4,visibility:1});
 let p=await Push.checkPermissions();if(p.receive!=='granted')p=await Push.requestPermissions();if(p.receive!=='granted')throw Error('手機未授權通知權限');
 await Push.register();return true;
}
async function registerWeb(){if(!('serviceWorker' in navigator)||!('Notification' in window))throw Error('此瀏覽器不支援網頁通知');
 if(!cfg.firebase?.projectId||!cfg.vapidKey)throw Error('請先完成 Firebase Web 配置與 VAPID 公開金鑰');
 const permission=await Notification.requestPermission();if(permission!=='granted')throw Error('網頁通知權限未開啟');
 const reg=await navigator.serviceWorker.register('./alerts-push/firebase-messaging-sw.js',{scope:'./alerts-push/'});
 const [{initializeApp},{getMessaging,getToken,isSupported}]=await Promise.all([import('https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js'),import('https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging.js')]);
 if(!await isSupported())throw Error('此瀏覽器無法使用 FCM');
 const app=initializeApp(cfg.firebase,'stocklab-alerts-071');
 const token=await getToken(getMessaging(app),{vapidKey:cfg.vapidKey,serviceWorkerRegistration:reg});if(!token)throw Error('FCM 未回傳推播 Token');
 await api('/api/register',{method:'POST',data:{token,platform:'web'}});write('此瀏覽器已訂閱四種訊號通知');
}
async function register(){if(!await registerAndroid())await registerWeb();}
async function health(){const h=await api('/api/health');write(`監控狀態：${h.last_ok||'尚未完成首次掃描'}${h.error?'；錯誤：'+h.error:''}`);}
async function candles(symbol){return api('/api/candles?symbol='+encodeURIComponent(symbol));}
function init(){if(!$('alerts-connect'))return;
 $('alerts-connect').onclick=()=>connect().catch(e=>write(e.message,true));
 $('alerts-save').onclick=()=>save().catch(e=>write(e.message,true));
 $('alerts-register').onclick=()=>register().catch(e=>write(e.message,true));
 $('alerts-health').onclick=()=>health().catch(e=>write(e.message,true));
 if(!cfg.workerUrl)write('請先完成 Cloudflare/Firebase 部署，再進行配對；目前不會背景推播。');
}
window.StocklabAlerts={hasCloud:()=>!!access&&!!cfg.workerUrl,getCandles:candles};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
