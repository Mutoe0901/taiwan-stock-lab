#!/usr/bin/env python3
"""Apply vetted v0.7.1 overlay to an existing v0.7.0 cloned project.
No credentials are read, and `main` is never pushed by this script.
"""
import json, re, shutil, sys
from pathlib import Path
src=Path(__file__).resolve().parent.parent
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
if not (root/'web'/'ab-strategies.js').exists() or not (root/'scripts'/'configure-android-signing.mjs').exists():
    raise SystemExit('請在已下載的 v0.7.0 台股研究室專案根目錄執行。')
if (root/'web'/'alerts-client.js').exists():
    raise SystemExit('v0.7.1 已經套用，停止以避免重複修改。')
html_path=root/'web'/'index.html';html=html_path.read_text(encoding='utf-8')
if '台股研究室 v0.7.0' not in html or '<section id="ab" class="page">' not in html:
    raise SystemExit('找不到預期的 v0.7.0 / A/B UI，停止避免破壞網站。')
block='''<article class="panel" id="alerts-panel"><h2>v0.7.1｜H1 雲端監控與四種訊號推播</h2>
<p>Fugle Key 存放在雲端 Secrets，不會出現在公開程式。A／B 兩套策略的 BUY IN／SELL IN／PROFIT OUT／FAIL OUT 均可推播；此功能需先部署 Worker、D1 及 Firebase。</p>
<div class="alerts-grid"><label>雲端配對密碼（僅當次登入，不保存）<input id="alerts-pair" type="password" autocomplete="off"></label><label>監控代號，逗號分隔（最多 10 檔）<input id="alerts-symbols" placeholder="2330,2382"></label><label>B 策略放量倍率<input type="number" id="alerts-ratio" value="1.2" min="0.1" max="10" step="0.1"></label></div>
<div class="alerts-types"><label><input type="checkbox" id="alerts-BUY-IN" checked> BUY IN</label><label><input type="checkbox" id="alerts-SELL-IN" checked> SELL IN</label><label><input type="checkbox" id="alerts-PROFIT-OUT" checked> PROFIT OUT</label><label><input type="checkbox" id="alerts-FAIL-OUT" checked> FAIL OUT</label></div>
<div class="actions"><button id="alerts-connect" type="button">連線雲端</button><button id="alerts-save" type="button">儲存設定</button><button id="alerts-register" type="button">啟用此裝置推播</button><button id="alerts-health" type="button">檢查監控狀態</button></div>
<p id="alerts-status" role="status" class="caption">尚未連線。</p><p class="caption">不會自動下單；通知是技術訊號，不代表保證獲利。雲端盤中 H1 監控與本機歷史回測資料來源可能不同，請核對資料時間與版本。</p></article>'''
html=html.replace('<section id="ab" class="page">','<section id="ab" class="page">'+block,1)
html=html.replace('v0.7.0','v0.7.1').replace('0.7.0','0.7.1')
html=html.replace('<link rel="stylesheet" href="ab.css?v=0.7.1">','<link rel="stylesheet" href="ab.css?v=0.7.1"><link rel="stylesheet" href="alerts.css?v=0.7.1">',1)
needle='<script src="ab-ui.js?v=0.7.1"></script>'
if needle not in html: raise SystemExit('無法安全插入新腳本，缺少 ab-ui 載入位置。')
html=html.replace(needle,'<script src="alerts-config.js?v=0.7.1"></script><script src="alerts-client.js?v=0.7.1"></script>'+needle,1)
html_path.write_text(html,encoding='utf-8')
# Make sure the new PWA files are fetched by the updated service worker.
sw=(root/'web'/'sw.js').read_text(encoding='utf-8')
sw=sw.replace('0.7.0','0.7.1')
sw=sw.replace("'./manifest.webmanifest'","'./alerts-config.js?v=0.7.1','./alerts-client.js?v=0.7.1','./alerts.css?v=0.7.1','./manifest.webmanifest'")
(root/'web'/'sw.js').write_text(sw,encoding='utf-8')
# Keep the same site and appId; bump only version and plugin config.
pkg_path=root/'package.json';pkg=json.loads(pkg_path.read_text(encoding='utf-8'))
pkg['version']='0.7.1';pkg['dependencies']['@capacitor/push-notifications']='^7.0.0'
pkg.setdefault('scripts',{})['build:worker']='node scripts/build-worker.mjs'
pkg['scripts']['test:alerts']='node --test tests/alerts.test.mjs'
pkg_path.write_text(json.dumps(pkg,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cap=root/'capacitor.config.json';c=json.loads(cap.read_text(encoding='utf-8'))
c.setdefault('plugins',{})['PushNotifications']={'presentationOptions':['badge','sound','alert']}
cap.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Updater used to display 0.7.0 in a compiled web runtime string.
main=root/'web'/'main.js';ms=main.read_text(encoding='utf-8');ms=ms.replace('0.7.0','0.7.1');main.write_text(ms,encoding='utf-8')
ab=root/'web'/'ab-ui.js';a=ab.read_text(encoding='utf-8');anchor='  async function fetchFugle() {'
if anchor not in a:raise SystemExit('缺少 fetchFugle，取消以避免策略錯誤')
cloud='''  async function fetchFugle() {
    if(window.StocklabAlerts?.hasCloud?.()) {
      const s=currentStock();if(!s)throw Error('尚未選擇股票');
      message('正在使用雲端已快取的 Fugle H1 行情…');
      const payload=await window.StocklabAlerts.getCandles(s.id);
      const bars=window.StocklabAB.cleanBars(payload.data);
      if(bars.length<65)throw Error('雲端歷史 H1 資料尚未達 65 根；請待背景掃描初始化。');
      imported.set(s.id,bars);$('ab-timeframe').value='H1';
      message('已讀取雲端 H1 行情 '+bars.length+' 根；最後資料：'+bars.at(-1).date);
      showCurrent();return;
    }
'''
a=a.replace(anchor,cloud,1)
a=a.replace('/* Taiwan Stock Lab A/B interface v0.7.0','/* Taiwan Stock Lab A/B interface v0.7.1')
a=a.replace('請輸入個人 Fugle API Key；金鑰不會永久儲存。','未配對雲端時，請輸入個人 Fugle API Key；建議先啟用雲端安全保存。')
ab.write_text(a,encoding='utf-8')
# Update signing versionName while preserving the prior stable keystore identity.
signer=root/'scripts'/'configure-android-signing.mjs';ss=signer.read_text(encoding='utf-8')
ss=ss.replace("versionName '0.7.0'","versionName '0.7.1'").replace('70000+','71000+')
signer.write_text(ss,encoding='utf-8')
workflow=root/'.github'/'workflows'/'android-build.yml';wf=workflow.read_text(encoding='utf-8').replace('v0.7.0','v0.7.1').replace("pkg.version === '0.7.0'","pkg.version === '0.7.1'").replace('expected 0.7.0','expected 0.7.1')
# Turn on android google-services.json build integration after sync, before APK build.
line='      - name: Add direct ChatGPT launcher'
if line not in wf:raise SystemExit('未知的 APK workflow，停止修改')
step='''      - name: Configure Firebase Android client
        shell: bash
        env:
          ANDROID_GOOGLE_SERVICES_JSON_BASE64: ${{ secrets.ANDROID_GOOGLE_SERVICES_JSON_BASE64 }}
        run: |
          if [ -z "$ANDROID_GOOGLE_SERVICES_JSON_BASE64" ]; then
            echo "Missing ANDROID_GOOGLE_SERVICES_JSON_BASE64 (Firebase config); stop to avoid a broken push build"; exit 1
          fi
          printf '%s' "$ANDROID_GOOGLE_SERVICES_JSON_BASE64" | base64 -d > android/app/google-services.json
          node -e "const c=require('./android/app/google-services.json');if(!c.project_info?.project_id||!c.client?.length)process.exit(1);"

'''
wf=wf.replace(line,step+line,1)
# First run tests and then build worker module, using installed Node.
wf=wf.replace('          npm run test:ab','          npm run test:ab\n          npm run build:worker\n          npm run test:alerts')
# Source guards validating existence but no publishing without runtime credentials.
workflow.write_text(wf.replace('node scripts/verify-stocklab-070.mjs','node scripts/verify-stocklab-071.mjs'),encoding='utf-8')
verifier=root/'scripts'/'verify-stocklab-070.mjs'
if verifier.exists():
    v=verifier.read_text(encoding='utf-8').replace('0.7.0','0.7.1')
    v=v.replace("[fs.existsSync('scripts/configure-android-signing.mjs')", "[fs.existsSync('web/alerts-client.js')&&fs.existsSync('cloudflare/src/index.mjs'),'cloud alerts files'],\n  [fs.existsSync('scripts/configure-android-signing.mjs')")
    (root/'scripts'/'verify-stocklab-071.mjs').write_text(v,encoding='utf-8')
manifest=root/'web'/'manifest.webmanifest'
if manifest.exists():
    m=json.loads(manifest.read_text(encoding='utf-8'));m['description']='台股 A/B 雙策略、H1 雲端監控、推播、盤後分析與回測。'
    manifest.write_text(json.dumps(m,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
for rel in ['web/alerts-config.js','web/alerts-client.js','web/alerts.css','web/alerts-push/firebase-messaging-sw.js','cloudflare/src/index.mjs','cloudflare/src/monitor.mjs','cloudflare/migrations/0001_init.sql','cloudflare/wrangler.toml','scripts/build-worker.mjs','tests/alerts.test.mjs']:
    dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src/rel,dest)
print('v0.7.1 已套用至',root)
print('GitHub push / Cloudflare deploy / Firebase settings have NOT been performed.')
