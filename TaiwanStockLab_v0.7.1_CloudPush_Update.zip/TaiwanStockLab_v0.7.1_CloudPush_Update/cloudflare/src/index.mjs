import AB from './strategy.mjs';
import {taipeiParts,isScanTime,normalize,replayEvents,eventId} from './monitor.mjs';
const BASE='https://api.fugle.tw/marketdata/v1.0/stock';
const FLAGS=['BUY IN','SELL IN','PROFIT OUT','FAIL OUT'];
const MAX_SYMBOLS=10;
const RESPONSE_HEADERS={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const json=(obj,status=200,extra={})=>new Response(JSON.stringify(obj),{status,headers:{...RESPONSE_HEADERS,...extra,'Content-Type':'application/json; charset=utf-8'}});
function allowed(origin,env){return !!origin && (env.ALLOWED_ORIGINS||'').split(',').map(s=>s.trim()).includes(origin);}
function cors(request,env){const o=request.headers.get('Origin');return allowed(o,env)?{'Access-Control-Allow-Origin':o,'Access-Control-Allow-Headers':'Authorization, Content-Type','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Vary':'Origin'}:{};}
function equalConstant(a,b){const a1=new TextEncoder().encode(a),b1=new TextEncoder().encode(b);let diff=a1.length^b1.length;for(let i=0;i<Math.max(a1.length,b1.length);i++)diff|=(a1[i]||0)^(b1[i]||0);return diff===0;}
function authorized(req,env){const t=req.headers.get('Authorization')||'';return !!env.CONTROL_TOKEN&&env.CONTROL_TOKEN.length>=32&&t.startsWith('Bearer ')&&equalConstant(t.slice(7),env.CONTROL_TOKEN);}
async function body(req){const raw=await req.text();if(raw.length>16000)throw Error('請求內容過大');return JSON.parse(raw);}
function validSymbols(input){if(!Array.isArray(input)||!input.length||input.length>MAX_SYMBOLS)throw Error('自選股需為 1～10 檔');const a=[...new Set(input.map(x=>String(x).trim()))];if(a.length!==input.length||a.some(x=>!/^[0-9A-Za-z]{4,8}$/.test(x)))throw Error('股票代碼格式錯誤或重複');return a;}
function validateFlags(x){if(!x||typeof x!=='object')throw Error('通知設定錯誤');return Object.fromEntries(FLAGS.map(k=>[k,x[k]===true]));}
const hash=async t=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t)))).map(b=>b.toString(16).padStart(2,'0')).join('');
async function settings(env){const v=await env.DB.prepare('SELECT symbols,flags,volume_ratio FROM settings WHERE id=1').first();return {symbols:JSON.parse(v.symbols),flags:JSON.parse(v.flags),volumeRatio:v.volume_ratio};}
async function fugle(path,env){const response=await fetch(BASE+path,{headers:{'X-API-KEY':env.FUGLE_API_KEY},cf:{cacheTtl:0}});if(!response.ok){if(response.status===429)throw Error('Fugle API 配額限制 (429)');throw Error('Fugle HTTP '+response.status);}return response.json();}
const isoTW=t=>taipeiParts(t).date;
function previousDay(now){const p=taipeiParts(now);return isoTW(Date.parse(p.date+'T00:00:00+08:00')-86400000);}
async function storeBars(env,symbol,bars){const cleaned=AB.cleanBars(bars);if(!cleaned.length)return;for(let i=0;i<cleaned.length;i+=75){const chunk=cleaned.slice(i,i+75);await env.DB.batch(chunk.map(b=>env.DB.prepare('INSERT INTO candles(symbol,ts,open,high,low,close,volume) VALUES (?,?,?,?,?,?,?) ON CONFLICT(symbol,ts) DO UPDATE SET open=excluded.open,high=excluded.high,low=excluded.low,close=excluded.close,volume=excluded.volume').bind(symbol,b.date,b.open,b.high,b.low,b.close,b.volume)));}}
async function historicalIfNeeded(env,symbol,now){const check=await env.DB.prepare('SELECT last_historical_day FROM cache_state WHERE symbol=?').bind(symbol).first();const yesterday=previousDay(now);
  if(check?.last_historical_day>=yesterday)return;
  const from=isoTW(now-170*86400000),to=yesterday;
  const path=`/historical/candles/${encodeURIComponent(symbol)}?timeframe=60&from=${from}&to=${to}&sort=asc`;
  const payload=await fugle(path,env);
  await storeBars(env,symbol,normalize(payload,now));
  await env.DB.prepare('INSERT INTO cache_state(symbol,last_historical_day,updated_at) VALUES(?,?,?) ON CONFLICT(symbol) DO UPDATE SET last_historical_day=excluded.last_historical_day,updated_at=excluded.updated_at').bind(symbol,yesterday,new Date(now).toISOString()).run();
}
async function latestBars(env,symbol){const r=await env.DB.prepare('SELECT ts AS date,open,high,low,close,volume FROM candles WHERE symbol=? ORDER BY ts DESC LIMIT 650').bind(symbol).all();return (r.results||[]).reverse();}
function closeEpoch(ev){const start=Date.parse(ev.bar_ts);const hour=taipeiParts(start).hour;return start+(hour===13?30:60)*60000;}
async function detect(env,symbol,now,opts){await historicalIfNeeded(env,symbol,now);
  const r=await fugle(`/intraday/candles/${encodeURIComponent(symbol)}?timeframe=60`,env);
  await storeBars(env,symbol,normalize(r,now));
  const bars=await latestBars(env,symbol);if(bars.length<65)return;
  const events=replayEvents(AB,bars,{volumeRatio:opts.volumeRatio,requireInstitution:false,allowShort:true});
  for(const ev of events){const age=now-closeEpoch(ev);if(age<0||age>10*60000||opts.flags[ev.kind]!==true)continue;
    const id=eventId(symbol,ev);
    await env.DB.prepare('INSERT OR IGNORE INTO events(id,symbol,strategy,kind,bar_ts) VALUES(?,?,?,?,?)').bind(id,symbol,ev.strategy,ev.kind,ev.bar_ts).run();
  }
}
const b64url=data=>btoa(String.fromCharCode(...new Uint8Array(data))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
async function oauth(env){const now=Math.floor(Date.now()/1000);const header=b64url(new TextEncoder().encode(JSON.stringify({alg:'RS256',typ:'JWT'})));
  const claims=b64url(new TextEncoder().encode(JSON.stringify({iss:env.FCM_CLIENT_EMAIL,scope:'https://www.googleapis.com/auth/firebase.messaging',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3500})));
  const pem=env.FCM_PRIVATE_KEY.replace(/\\n/g,'\n').replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/g,'');
  const bytes=Uint8Array.from(atob(pem),c=>c.charCodeAt(0));
  const key=await crypto.subtle.importKey('pkcs8',bytes,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);
  const signed=await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,new TextEncoder().encode(header+'.'+claims));
  const assertion=header+'.'+claims+'.'+b64url(signed);
  const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion})});
  if(!r.ok)throw Error('FCM OAuth authentication error '+r.status);
  const data=await r.json();return data.access_token;
}
async function sendFcm(env,access,token,ev){const title=`台股研究室｜${ev.strategy} ${ev.kind}`;
  const body=`${ev.symbol} ${ev.kind}（已收盤 H1）｜${ev.bar_ts}`;
  const r=await fetch(`https://fcm.googleapis.com/v1/projects/${encodeURIComponent(env.FCM_PROJECT_ID)}/messages:send`,{method:'POST',headers:{Authorization:'Bearer '+access,'Content-Type':'application/json'},body:JSON.stringify({message:{token,notification:{title,body},data:{symbol:ev.symbol,strategy:ev.strategy,kind:ev.kind,bar_ts:ev.bar_ts,event_id:ev.id},android:{priority:'HIGH',notification:{channel_id:'stocklab_signals',tag:ev.id}},webpush:{notification:{tag:ev.id,renotify:false},fcm_options:{link:env.PUBLIC_SITE_URL||'https://taiwan-stock-lab-mutoe.mutoe-chen-2361.chatgpt.site/#ab'}}}})});
  if(!r.ok){const error=await r.text();if((r.status===400||r.status===404)&&/UNREGISTERED|registration-token-not-registered|INVALID_ARGUMENT/.test(error))return {invalid:true};throw Error('FCM HTTP '+r.status);}
  return {invalid:false};
}
async function drain(env){
  // Retry abandoned claims after a worker interruption; delivery is at-least-once.
  await env.DB.prepare("UPDATE deliveries SET status='pending' WHERE status='sending' AND claimed_at<? AND attempts<3").bind(Date.now()-5*60000).run();
  const events=(await env.DB.prepare("SELECT e.id,e.symbol,e.strategy,e.kind,e.bar_ts FROM events e WHERE e.created_at >= datetime('now','-2 hours') ORDER BY e.created_at LIMIT 80").all()).results||[];
  const subs=(await env.DB.prepare('SELECT token_hash,fcm_token FROM subscriptions WHERE active=1 LIMIT 30').all()).results||[];
  if(!events.length||!subs.length)return;
  const statements=[];for(const ev of events)for(const sub of subs)statements.push(env.DB.prepare('INSERT OR IGNORE INTO deliveries(event_id,token_hash) VALUES(?,?)').bind(ev.id,sub.token_hash));
  if(statements.length)await env.DB.batch(statements);
  const pending=(await env.DB.prepare("SELECT d.event_id,d.token_hash,s.fcm_token,e.symbol,e.strategy,e.kind,e.bar_ts FROM deliveries d JOIN subscriptions s ON s.token_hash=d.token_hash AND s.active=1 JOIN events e ON e.id=d.event_id WHERE d.status='pending' AND d.attempts<3 ORDER BY e.created_at LIMIT 80").all()).results||[];
  if(!pending.length)return;
  const access=await oauth(env);
  for(const ev of pending){const claim=await env.DB.prepare("UPDATE deliveries SET status='sending',attempts=attempts+1,claimed_at=? WHERE event_id=? AND token_hash=? AND status='pending'").bind(Date.now(),ev.event_id,ev.token_hash).run();
    if(!claim.meta?.changes)continue;
    try{const result=await sendFcm(env,access,ev.fcm_token,{...ev,id:ev.event_id});
      if(result.invalid)await env.DB.prepare('UPDATE subscriptions SET active=0 WHERE token_hash=?').bind(ev.token_hash).run();
      await env.DB.prepare("UPDATE deliveries SET status='sent',sent_at=datetime('now') WHERE event_id=? AND token_hash=?").bind(ev.event_id,ev.token_hash).run();
    }catch(error){await env.DB.prepare("UPDATE deliveries SET status='pending',last_error=? WHERE event_id=? AND token_hash=?").bind(String(error.message).slice(0,160),ev.event_id,ev.token_hash).run();}
  }
}
async function run(env,now=Date.now()){if(!isScanTime(now))return;
  try{const opts=await settings(env);const errors=[];for(const symbol of opts.symbols){try{await detect(env,symbol,now,opts);}catch(e){errors.push(symbol+': '+String(e.message));console.error('H1 scan failed',symbol,String(e.message));}}
    await drain(env);
    await env.DB.prepare("UPDATE health SET last_run=?,last_ok=?,error=? WHERE id=1").bind(new Date(now).toISOString(),errors.length===opts.symbols.length?null:new Date(now).toISOString(),errors.length?errors.join('; ').slice(0,180):null).run();
  }catch(error){await env.DB.prepare('UPDATE health SET last_run=?,error=? WHERE id=1').bind(new Date(now).toISOString(),String(error.message).slice(0,180)).run();throw error;}
}
async function handler(request,env){const originHeaders=cors(request,env);if(request.method==='OPTIONS')return new Response(null,{status:allowed(request.headers.get('Origin'),env)?204:403,headers:originHeaders});
  if(!authorized(request,env))return json({error:'未授權，請檢查配對密碼'},401,originHeaders);
  const url=new URL(request.url),path=url.pathname;
  try{
    if(path==='/api/settings'&&request.method==='GET')return json({...await settings(env),enabled:true},200,originHeaders);
    if(path==='/api/settings'&&request.method==='POST'){
      const input=await body(request),symbols=validSymbols(input.symbols),flags=validateFlags(input.flags);
      const ratio=Number(input.volumeRatio);if(!Number.isFinite(ratio)||ratio<0.1||ratio>10)throw Error('成交量倍率必須在 0.1~10');
      await env.DB.prepare("UPDATE settings SET symbols=?,flags=?,volume_ratio=?,updated_at=datetime('now') WHERE id=1").bind(JSON.stringify(symbols),JSON.stringify(flags),ratio).run();return json({saved:true,symbols,flags,volumeRatio:ratio},200,originHeaders);
    }
    if(path==='/api/register'&&request.method==='POST'){
      const v=await body(request);if(typeof v.token!=='string'||v.token.length<30||v.token.length>4096||!['android','web'].includes(v.platform))throw Error('裝置推播資料不正確');
      const key=await hash(v.token);await env.DB.prepare("INSERT INTO subscriptions(token_hash,fcm_token,platform) VALUES(?,?,?) ON CONFLICT(token_hash) DO UPDATE SET fcm_token=excluded.fcm_token,platform=excluded.platform,active=1,updated_at=datetime('now')").bind(key,v.token,v.platform).run();
      return json({registered:true},200,originHeaders);
    }
    if(path==='/api/candles'&&request.method==='GET'){
      const symbol=url.searchParams.get('symbol')||'';if(!/^[0-9A-Za-z]{4,8}$/.test(symbol))throw Error('股票代號不正確');
      return json({symbol,timeframe:'60',data:await latestBars(env,symbol)},200,originHeaders);
    }
    if(path==='/api/health'&&request.method==='GET'){
      const state=await env.DB.prepare('SELECT last_run,last_ok,error FROM health WHERE id=1').first();return json({worker:'v0.7.1',...state},200,originHeaders);
    }
    return json({error:'找不到端點'},404,originHeaders);
  }catch(err){return json({error:String(err.message)},400,originHeaders);}
}
export default {fetch:handler,scheduled(ctrl,env,ctx){ctx.waitUntil(run(env,Date.now()));}};
export const __test={run,validSymbols,validateFlags};
